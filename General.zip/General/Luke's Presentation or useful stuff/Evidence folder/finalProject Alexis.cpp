#include<iostream>
#include<fstream>
#include<iomanip>
using namespace std;

//student class
class student {
        int studentNum; //student number
        char studentName[50]; //student name
        char gender; //student gender
        int mathsMarks; //student maths marks out of 100
        int scienceMarks; //student science marks out of 100
        int englishMarks; //student english marks out of 100
        int compSciMarks; //student computer science marks out of 100
        double overallPercentage; //student percentage of all subjects combined
        char overallGrade; //letter grade of student
        void calculateGrade(); //calculates the letter grade of student
    public:
        void getStudentDetails(); //user able to enter in student details
        void showStudentDetails() const; //display student details
        int returnStudentNumber() const; //returns the student number
        void tab() const; //tabs for consistent layout
};

//calculates the letter grade of student
void student:: calculateGrade() { 
    overallPercentage = ((mathsMarks + scienceMarks + englishMarks + compSciMarks)/4); //calculating overall per of 4 subjects
    if (overallPercentage >= 75) { //over 75%
        overallGrade = 'A';
    } else if (overallPercentage >= 60) { //over 65%
        overallGrade = 'B';
    } else if (overallPercentage >= 45) { //over 45%
        overallGrade = 'C';
    } else if (overallPercentage >= 30) { //over 30%
        overallGrade = 'D';
    } else { //anything under 30%
        overallGrade = 'E';
    }
}

//user enters in student details
void student:: getStudentDetails() {
    cout << "\n\nInput student details \n";
    cout << "Enter in student number: ";
    cin >> studentNum;
    cout << "Enter in student name: ";
    cin.ignore(); 
    cin.getline(studentName, 50);
    cout << "Enter in student gender (M/F): ";
    cin >> gender;
    cout << "Enter in student Maths mark out of 100 : ";
    cin >> mathsMarks;
    cout << "Enter in student Science mark out of 100 : ";
    cin >> scienceMarks;
    cout << "Enter in student English mark out of 100 : ";
    cin >> englishMarks;
    cout << "Enter in student Computer Science mark out of 100 : ";
    cin >> compSciMarks;
    calculateGrade();
}

//displays student detials in list form
void student:: showStudentDetails() const {
    cout<<"Student number: " << studentNum << endl;
    cout<<"Student name: " << studentName << endl;
    cout<<"Gender: " << gender << endl;
    cout<<"Maths mark: " << mathsMarks << endl;
    cout<<"Science mark: " << scienceMarks << endl;
    cout<<"English mark: " << englishMarks << endl;
    cout<<"Computer Science mark: " << compSciMarks << endl;
    cout<<"Overall percentage: " << overallPercentage << endl;
    cout<<"Overall letter grade: " << overallGrade << endl;
}

//returns the student number
int student:: returnStudentNumber() const {
    return studentNum;
}

//tabs for consistent layout in table
void student::tab() const {
    cout<<studentNum<<setw(10)<<" "<<studentName<<setw(7)<<gender<<setw(9)<<mathsMarks<<setw(4)<<scienceMarks<<setw(4) 
    <<englishMarks<<setw(4)<<compSciMarks<<setw(5)<<overallPercentage<<setw(5)<<overallGrade<<endl;
}

//function declaration
void addstudent(); //adds student record
void displayAllStuRecords(); //displays all student records in list form
void displaySearchStuRecords(); //searches for specific student record from student number
void changeStuRecord(); //modify/change a student record
void deleteStudentRecord(); //delete a student record
void allResultTable(); //displays student records in table form
void entryEditMenu(); //entry or edit menu (from main menu)
void displayMenu(); //display menu (from main menu)

//main menu of program
int mainMenu() {
    int choice;
    do {
        system("cls");
        cout << "\n\nSTUDENT REPORT MANAGER - Main Menu \n";
        cout << "------------------------------------\n";
        cout << "1. Entry/edit menu\n";
        cout << "2. Display menu\n";
        cout << "3. Exit program\n";
        cout << "Enter in choice: ";
        cin >> choice;
        system("cls");

        switch (choice) {
            case 1: entryEditMenu(); //goes to the entry/edit menu
            case 2: displayMenu(); //goes to the display menu 
            case 3: exit(EXIT_FAILURE);
            default: cout<<"\a";
        }
    } while (choice != 3);
    return 0;
}

//add new student record
void addStudent() {
    student st;
    ofstream fout;
    fout.open("stu.dat",ios::binary|ios::out|ios::app);
    st.getStudentDetails();
    fout.write((char*)&st,sizeof(st));
    fout.close();
    cout << "Student data saved. Student record successfully created";
    mainMenu();
}

//displays all student records in list form
void displayAllStuRecords() {
    student s;
    ifstream inFile;
    inFile.open("stu.dat",ios::binary);
    if(!inFile)
    {
        cout<<"File couldn't be opened. Press any key to continue.";
        cin.ignore();
        cin.get();
        return;
    }
    cout<<"\n\nDisplay all student records \n";
    while(inFile.read(reinterpret_cast<char *> (&s), sizeof(student)))
    {
        s.showStudentDetails();
        cout<<"\n---------------------------\n";
    }
    inFile.close();
    cin.ignore();
    cin.get();
    mainMenu();
}

//searches for specific student record from student number
void displaySearchStuRecords(int stuNum) {
    student s;
    ifstream inFile;
    inFile.open("stu.dat",ios::binary);
    if(!inFile)
    {
        cout<<"File couldn't be opened. Press any key to continue.";
        cin.ignore();
        cin.get();
        return;
    }
    bool flag=false;
    while(inFile.read(reinterpret_cast<char *> (&s), sizeof(student)))
    {
        if(s.returnStudentNumber()==stuNum)
        {
            s.showStudentDetails();
            flag=true;
        }
    }
    inFile.close();
    if(flag==false)
        cout<<"Record does not exist";
    cin.ignore();
    cin.get();
    mainMenu();
}

//modify/change a student record
void changeStuRecord(int stuNum) {
    bool found=false;
    student s;
    fstream File;
    File.open("stu.dat",ios::binary|ios::in|ios::out);
    if(!File)
    {
        cout<<"File could not be opened. Press any key to continue";
        cin.ignore();
        cin.get();
        return;
    }
    while(!File.eof() && found==false) {
        File.read(reinterpret_cast<char *> (&s), sizeof(student));
        if(s.returnStudentNumber()==stuNum) {
            s.showStudentDetails();
            cout<<"\nEnter in new details of student";
            s.getStudentDetails();
            int pos=(-1)*static_cast<int>(sizeof(s));
            File.seekp(pos,ios::cur);
            File.write(reinterpret_cast<char *> (&s), sizeof(student));
            cout<<"Student record has been updated";
            found=true;
        }
    }
    File.close();
    if(found==false) {
        cout<<"Record does not exist";
    }
    cin.ignore();
    cin.get();
    mainMenu();
}

//delete a student record
void deleteStudentRecord(int stuNum) {
    student s;
    ifstream inFile;
    inFile.open("stu.dat",ios::binary); //open file
    if(!inFile) //error to open file
    {
        cout<<"File could not be opened. Press any key to continue";
        cin.ignore();
        cin.get();
        return;
    }
    ofstream outFile;
    outFile.open("temporary.dat",ios::out); //temporary saves data in temp file
    inFile.seekg(0,ios::beg);
    while(inFile.read(reinterpret_cast<char *> (&s), sizeof(student)))
    {
        if(s.returnStudentNumber()!=stuNum)
        {
            outFile.write(reinterpret_cast<char *> (&s), sizeof(student));
        }
    }
    outFile.close();
    inFile.close();
    remove("stu.dat"); //delete old main file
    rename("temporary.dat","stu.dat"); //replace the temp file name to main file name
    cout<<"student record deleted.";
    cin.ignore();
    cin.get();
    mainMenu();
}

//displays student records in table form
void allResultTable() {
    student s;
    ifstream inFile;
    inFile.open("stu.dat",ios::binary); //opens file "stu.dat"
    if(!inFile) //error to open file
    {
        cout<<"File could not be opened. Press any key to continue.";
        cin.ignore();
        cin.get();
        return;
    }
    cout << "\n\nDisplay all student records in table format \n";
    cout << "-------------------------------------------------------------\n";
    cout << "Stu Num       Name     Gender    M   S   E   CS   %  Grade"<<endl;
    cout << "-------------------------------------------------------------\n";
    while(inFile.read(reinterpret_cast<char *> (&s), sizeof(student))) { //outputs the student details in table format
        s.tab(); //tabs to make it fit correctly under headings of table
    }
    cin.ignore();
    cin.get();
    inFile.close();
    mainMenu();
}

//entry or edit menu (from main menu)
void entryEditMenu() {
    int choice; //choice entered by user
    int number; //student number that user enters
    do {
        system("cls");
        cout << "\n\nSTUDENT REPORT MANAGER- Entry/Edit Menu\n";
        cout << "----------------------------------------\n";
        cout << "1. Create a student record\n";
        cout << "2. Modify a student record\n";
        cout << "3. Delete a student record\n";
        cout << "4. Back to main menu\n";
        cout << "Enter in choice: ";
        cin >> choice;
        system("cls");

        switch (choice) {
            case 1: addStudent(); //goes to function to add new student
            case 2: cout << "\nenter in student number: "; cin >> number; changeStuRecord(number); break; //asks for student number and sends to function to change student record
            case 3: cout << "\nenter in student number: "; cin >> number; deleteStudentRecord(number); break; //asks for student number and sends to function to delete student record
            case 4: mainMenu(); //back to main menu
            default: cout<<"\a"; entryEditMenu();
        }
        system("pause");
    } while (choice);
}

//display menu (from main menu)
void displayMenu() {
    int choice; //choice entered by user
    int number; //student number that user enters
    do {
        system("cls");
        cout << "\n\nSTUDENT REPORT MANAGER - Display Menu\n";
        cout << "--------------------------------------\n";
        cout << "1. Display all student records in list form\n";
        cout << "2. Display all student records in table form\n";
        cout << "3. Search for a specific student record\n";
        cout << "4. Back to main menu\n";
        cout << "Enter in choice: ";
        cin >> choice;
        system("cls"); //clear screen

        switch (choice) {
            case 1: displayAllStuRecords(); //goes to function to display student records in list form
            case 2: allResultTable(); //goes to function to display student records in table form
            case 3: cout << "\nenter in student number: "; cin >> number; displaySearchStuRecords(number); break; //asks for user to enter student number and sends to function to display specific student record
            case 4: mainMenu(); //back to main menu
            default: cout<<"\a"; displayMenu();
        }
        system("pause");
    } while (choice);
}

//main function
int main() {
    mainMenu(); //runs main menu function
}